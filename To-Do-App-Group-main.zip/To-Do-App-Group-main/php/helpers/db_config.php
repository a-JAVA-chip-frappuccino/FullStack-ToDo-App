<?php

    // DB information
    $server = "localhost";
    $username = "root";
    $password = "";
    $database = "todo";

?>